package basics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class leapfrog {
	WebDriver driver;
	
	@BeforeTest
	public void invokeBrowser(){
		try {
			System.setProperty("webdriver.gecko.driver", "E:\\GeckoDriver\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			
			driver.get("http://toolsqa.com/automation-practice-form/");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	@Test
	public void personalInfo(){
		try {
			//Name
			driver.findElement(By.name("firstname")).sendKeys("Rajiv");
			driver.findElement(By.cssSelector("input[name=lastname]")).sendKeys("Parajuli");
			
			//Sex
			driver.findElement(By.id("sex-0")).click();
			
			//Years of Experience
			driver.findElement(By.id("exp-0")).click();
			
			//Date
			WebElement dateBox = driver.findElement(By.id("datepicker"));
			dateBox.sendKeys("05-27-2017");
			
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("scroll(0, 500)");
			
			//Profession
			driver.findElement(By.id("profession-1")).click();
			
			//Profile Picture
			driver.findElement(By.id("photo")).sendKeys("E:\\passportsize_fine.png");
						
			Thread.sleep(2000);
			
			//Automation Tool
			driver.findElement(By.xpath("//*[@id='tool-2']")).click();

			//Continents
			Select dropdown = new Select(driver.findElement(By.xpath("//*[@id='continents']")));
			dropdown.selectByIndex(0);
			
			//Selenium Commands
			Select oSelect = new Select(driver.findElement(By.name("selenium_commands")));
			oSelect.selectByVisibleText("WebElement Commands");
			
			driver.findElement(By.xpath("//*[@id='submit']")).click();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.close();
	}
}